var searchData=
[
  ['display_59',['Display',['../namespacemain__stitcher.html#a773ec2d90bc90aa1537f38dcb46ca6ba',1,'main_stitcher']]]
];
