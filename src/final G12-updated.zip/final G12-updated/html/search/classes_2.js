var searchData=
[
  ['mainstitcher_49',['MainStitcher',['../classmain__stitcher_1_1_main_stitcher.html',1,'main_stitcher']]]
];
