var searchData=
[
  ['config_5freader_50',['config_reader',['../namespaceconfig__reader.html',1,'']]]
];
