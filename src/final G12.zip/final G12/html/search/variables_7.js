var searchData=
[
  ['originalimage_89',['originalImage',['../classimage__rw_1_1_image_r_w.html#aaf8199d8076cef776cd8732d608f8878',1,'image_rw::ImageRW']]]
];
