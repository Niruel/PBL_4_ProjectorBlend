var searchData=
[
  ['img_5fheight_81',['img_height',['../classimage__rw_1_1_image_r_w.html#a5d609052a3dccf1f06248996b33b588b',1,'image_rw::ImageRW']]],
  ['img_5fwidth_82',['img_width',['../classimage__rw_1_1_image_r_w.html#afb0e1dc64838dfec2d0e89dfd70a2862',1,'image_rw::ImageRW']]]
];
