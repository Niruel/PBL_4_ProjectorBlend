var searchData=
[
  ['config_5freader_2epy_54',['config_reader.py',['../config__reader_8py.html',1,'']]]
];
