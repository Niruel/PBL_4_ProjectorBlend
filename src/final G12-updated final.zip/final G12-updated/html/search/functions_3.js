var searchData=
[
  ['stitchimage_69',['stitchImage',['../classmain__stitcher_1_1_main_stitcher.html#a96bb031e24b3811cef12d85176de0678',1,'main_stitcher::MainStitcher']]]
];
