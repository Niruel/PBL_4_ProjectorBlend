var searchData=
[
  ['rightimage_38',['rightImage',['../namespacemain.html#a708ac4ec7a137f02058272200cd88914',1,'main']]],
  ['rightmaskarea_39',['rightMaskArea',['../namespacemain.html#a55f6c93a1806f70f69848a6440f1e2f2',1,'main']]],
  ['rightunmaskarea_40',['rightUnmaskArea',['../namespacemain.html#ae2372092f3b18cc227874b5cf63c8a62',1,'main']]]
];
